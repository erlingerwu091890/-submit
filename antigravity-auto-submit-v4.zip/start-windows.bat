@echo off
chcp 65001 >nul
title Antigravity Auto-Submit

echo ====================================================
echo  Antigravity Auto-Submit Daemon
echo  Killing existing Antigravity processes...
echo ====================================================
taskkill /F /IM Antigravity.exe >nul 2>&1
timeout /t 2 /nobreak >nul

echo  Starting Antigravity with debug port 9333...
start "" "%LOCALAPPDATA%\Programs\antigravity\Antigravity.exe" --remote-debugging-port=9333
timeout /t 4 /nobreak >nul

echo  Starting Auto-Submit daemon...
echo ====================================================
node "%~dp0daemon.js" 9333
pause
