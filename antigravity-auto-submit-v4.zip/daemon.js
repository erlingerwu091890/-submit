/**
 * Antigravity Auto-Submit Daemon v4
 * ----------------------------------
 * Polls ALL open Antigravity pages every 800ms via CDP.
 * Automatically clicks [Submit] on any page where it appears.
 *
 * Usage:
 *   node daemon.js [CDP_PORT]
 *
 *   Windows default port: 9333
 *   Mac default port:     9222
 *
 * How to start Antigravity with debug port:
 *   Windows: Antigravity.exe --remote-debugging-port=9333
 *   Mac:     /Applications/Antigravity.app/Contents/MacOS/Antigravity --remote-debugging-port=9222
 */

const http = require('http');

const PORT = parseInt(process.argv[2] || '9333', 10);
const POLL_MS = 800;

console.log('======================================================');
console.log(' Antigravity Auto-Submit Daemon v4');
console.log(' CDP Port  : ' + PORT);
console.log(' Interval  : ' + POLL_MS + 'ms');
console.log(' Scope     : ALL open Antigravity pages');
console.log('======================================================');
console.log('');

// JS injected into each page to find and click the Submit button
const CLICK_SCRIPT = '(function(){' +
  'var els=document.querySelectorAll("button,[role=button]");' +
  'for(var i=0;i<els.length;i++){' +
    'var el=els[i];' +
    'if(el.disabled||el.offsetWidth===0||el.offsetHeight===0)continue;' +
    'var t=(el.innerText||"").trim().toLowerCase();' +
    // Match: "submit", "submit ⏎", "submit⏎"
    'if(t==="submit"||t==="submit \u23ce"||t==="submit\u23ce"){' +
      'el.click();return "OK:"+t;' +
    '}' +
  '}' +
  'return "NONE";' +
'})()';

function fetchJson(path) {
  return new Promise((resolve) => {
    const req = http.get('http://127.0.0.1:' + PORT + path, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { resolve([]); } });
    });
    req.on('error', () => resolve([]));
    req.setTimeout(2000, () => { req.destroy(); resolve([]); });
  });
}

function evalOnPage(wsUrl) {
  return new Promise((resolve) => {
    let done = false;
    let ws;
    try { ws = new WebSocket(wsUrl); } catch(e) { resolve('ERR'); return; }

    const timer = setTimeout(() => {
      if (!done) { done = true; try { ws.close(); } catch(e){} resolve('TIMEOUT'); }
    }, 2000);

    ws.onopen = () => {
      ws.send(JSON.stringify({
        id: 1,
        method: 'Runtime.evaluate',
        params: { expression: CLICK_SCRIPT, returnByValue: true }
      }));
    };
    ws.onmessage = (e) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try { ws.close(); } catch(ex) {}
      try {
        const msg = JSON.parse(e.data);
        resolve(msg.result && msg.result.result ? msg.result.result.value : 'ERR');
      } catch(ex) { resolve('ERR'); }
    };
    ws.onerror = () => {
      if (!done) { done = true; clearTimeout(timer); resolve('ERR'); }
    };
  });
}

let lastError = '';

async function pollAll() {
  const pages = await fetchJson('/json/list');

  if (!pages || pages.length === 0) {
    const msg = 'Waiting for Antigravity (port ' + PORT + ')...';
    if (lastError !== msg) {
      console.log('[' + new Date().toLocaleTimeString() + '] ' + msg);
      lastError = msg;
    }
    return;
  }

  if (lastError) {
    console.log('[' + new Date().toLocaleTimeString() + '] Connected! Found ' + pages.length + ' page(s).');
    lastError = '';
  }

  for (const page of pages) {
    if (page.type !== 'page' || !page.webSocketDebuggerUrl) continue;
    const result = await evalOnPage(page.webSocketDebuggerUrl);
    if (result && result.startsWith('OK:')) {
      const btn = result.replace('OK:', '');
      const title = (page.title || page.url || '').substring(0, 60);
      console.log('[' + new Date().toLocaleTimeString() + '] >> CLICKED [' + btn + '] on: "' + title + '"');
    }
  }
}

setInterval(pollAll, POLL_MS);
pollAll();
