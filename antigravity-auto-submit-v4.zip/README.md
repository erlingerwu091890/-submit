# Antigravity Auto-Submit

自动点击 Antigravity 所有对话页面的 **[Submit ⏎]** 按钮，解放双手，彻底免确认。

## 环境要求

- **Node.js 18+**：https://nodejs.org/
- **Antigravity 客户端**（桌面版）

---

## Windows 使用方法

1. 双击 **`start-windows.bat`**
2. 脚本会自动：
   - 关闭现有 Antigravity
   - 以调试端口 9333 重新启动 Antigravity
   - 在当前窗口运行守护进程
3. 守护进程窗口保持打开，看到 `>> CLICKED [submit]` 说明生效了

**如果你已经手动启动了 Antigravity（带 `--remote-debugging-port=9333`）：**
```
node daemon.js 9333
```

---

## macOS 使用方法

1. 打开终端（Terminal），进入本目录：
   ```bash
   cd /path/to/antigravity-auto-submit
   chmod +x start-mac.sh
   bash start-mac.sh
   ```
2. 脚本会自动关闭并以调试端口 9222 重启 Antigravity，然后启动守护进程

**如果你已经手动启动了 Antigravity（带 `--remote-debugging-port=9222`）：**
```bash
node daemon.js 9222
```

---

## 手动启动 Antigravity（带调试端口）

### Windows
```
%LOCALAPPDATA%\Programs\antigravity\Antigravity.exe --remote-debugging-port=9333
```

### macOS
```bash
/Applications/Antigravity.app/Contents/MacOS/Antigravity --remote-debugging-port=9222
```

---

## 工作原理

每隔 800ms，守护进程通过 Chrome DevTools Protocol（CDP）连接到 Antigravity 的所有打开页面，检查是否存在文本为 `Submit` 或 `Submit ⏎` 的按钮——若存在则立即点击。

- 只点 `Submit` 按钮，其他按钮一概不动
- 安全：用户正在输入框打字时不会触发
- 支持多对话、多标签页同时监控

---

## 停止方法

关闭守护进程终端窗口，或按 `Ctrl+C` 即可停止。
