#!/bin/bash
# Antigravity Auto-Submit - macOS Launcher
# Usage: double-click or run in Terminal: bash start-mac.sh

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ANTIGRAVITY_APP="/Applications/Antigravity.app/Contents/MacOS/Antigravity"
PORT=9222

echo "======================================================"
echo " Antigravity Auto-Submit Daemon (macOS)"
echo "======================================================"

# Kill existing Antigravity
echo "[1/3] Killing existing Antigravity..."
pkill -f "Antigravity" 2>/dev/null
sleep 1

# Check if Antigravity exists
if [ ! -f "$ANTIGRAVITY_APP" ]; then
  echo "[ERROR] Antigravity not found at: $ANTIGRAVITY_APP"
  echo "        Please edit this script and update ANTIGRAVITY_APP path."
  read -p "Press Enter to exit..."
  exit 1
fi

# Start Antigravity with debug port
echo "[2/3] Starting Antigravity with debug port $PORT..."
"$ANTIGRAVITY_APP" --remote-debugging-port=$PORT &
sleep 4

# Start daemon
echo "[3/3] Starting Auto-Submit daemon..."
echo "======================================================"
node "$SCRIPT_DIR/daemon.js" $PORT
